---
title: "RFC 01: Clustering & Redis Adapters"
status: "Draft"
---

# RFC 01: Implementing Clustering with Redis

## Objective
Enable OpenClaw Gateways to run in a stateless Cluster Mode (active-active) by moving ephemeral state from RAM to Redis.

## 1. The `ClusterState` Interface

We need to abstract `server-runtime-state.ts` into an interface.

```typescript
export interface ClusterStateAdapter {
  // Chat State
  setChatRun(sessionId: string, runConfig: ChatRunEntry, ttlMs: number): Promise<void>;
  getChatRun(sessionId: string): Promise<ChatRunEntry | null>;
  deleteChatRun(sessionId: string): Promise<void>;

  // Pub/Sub capabilities
  publish(channel: string, message: any): Promise<void>;
  subscribe(channel: string, handler: (msg: any) => void): Promise<void>;
}
```

## 2. Redis Data Structures

### A. Active Chat Runs
*   **Key**: `openclaw:run:{sessionId}`
*   **Type**: `Hash`
*   **Fields**:
    *   `nodeId`: The ID of the Gateway instance currently holding the WebSocket.
    *   `model`: The LLM model in use.
    *   `status`: "running" | "idle".
*   **TTL**: 30 minutes (auto-expire if node crashes).

### B. Event Broadcasting
We will use Redis Pub/Sub to replace the local `clients.forEach()` loop in `server.impl.ts`.

*   **Channel**: `openclaw:events:broadcast`
*   **Message Payload**:
    ```json
    {
      "event": "chat.completion",
      "payload": { ... },
      "targetSessionId": "123" // Optional: if targeting specific user
    }
    ```

## 3. Implementation Steps

1.  **Refactor**: Modify `createGatewayRuntimeState` to accept a `ClusterStateAdapter`.
2.  **Default**: Provide `MemoryClusterAdapter` (maps) for Open Source users.
3.  **Enterprise**: Implement `RedisClusterAdapter` using `ioredis`.
4.  **Wiring**: In `server.impl.ts`, listen to Redis updates and forward them to local WebSockets if the user is connected to *this* node.
