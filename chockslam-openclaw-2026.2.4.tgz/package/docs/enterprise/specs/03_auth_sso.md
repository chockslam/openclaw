---
title: "RFC 03: SSO & RBAC"
status: "Draft"
---

# RFC 03: Authentication & Authorization

## Objective
Replace the simple "Shared Token" auth with a robust Identity Provider (IdP) integration for enterprise security.

## 1. The `AuthProvider` Interface

Refactor `gateway/auth.ts`:

```typescript
export interface AuthProvider {
  /**
   * Validates a request (HTTP Headers or WS Handshake).
   * Returns the User Principal if valid.
   */
  validate(req: IncomingMessage): Promise<UserPrincipal | null>;
  
  /**
   * Returns the login URL for the frontend (e.g. Okta redirect).
   */
  getLoginUrl(): string;
}

export type UserPrincipal = {
  id: string;
  email: string;
  roles: string[]; // ['admin', 'viewer']
};
```

## 2. Implementation: OIDC Adapter
We will use `openid-client` to implement the `OIDCAuthProvider`.

*   **Config**:
    ```yaml
    auth:
      provider: "oidc"
      issuer: "https://auth.acme.com"
      clientId: "..."
      clientSecret: "..."
    ```
*   **Flow**:
    1.  User visits Dashboard -> Redirects to Okta.
    2.  Okta redirects back with `code`.
    3.  Gateway exchanges `code` for `access_token` + `id_token`.
    4.  Gateway issues a `session_cookie` to the browser.

## 3. RBAC Enforcement

Modify `authorizeGatewayMethod` in `server-methods.ts` to check `UserPrincipal.roles`.

```typescript
function authorize(method: string, user: UserPrincipal) {
  const methodScope = SCOPE_MAP[method]; // e.g., 'write'
  
  if (methodScope === 'admin' && !user.roles.includes('admin')) {
    throw new Error("Forbidden");
  }
}
```
