---
title: "RFC 05: Secrets Management"
status: "Draft"
---

# RFC 05: Secrets Management Adapter

## Objective
Remove reliance on `.env` files for storing sensitive credentials (API keys, DB passwords). Enable integration with enterprise secret stores.

## 1. The `SecretsProvider` Interface

We need an abstraction for fetching secrets at runtime.

```typescript
export interface SecretsProvider {
  /**
   * Fetch a secret by key.
   * @param key The logical name (e.g. "OPENAI_API_KEY")
   */
  getSecret(key: string): Promise<string | null>;
}
```

## 2. Implementations

### A. EnvSecretsProvider (Default)
Reads from `process.env`. Used for local dev / open source.

### B. VaultSecretsProvider (Enterprise)
Connects to HashiCorp Vault.
*   **Config**:
    ```yaml
    secrets:
      provider: "vault"
      url: "https://vault.internal:8200"
      authAttributes: { ... }
    ```
*   **Library**: `node-vault` client.

### C. AWSSecretsManagerProvider (Enterprise)
Connects to AWS Secrets Manager.
*   **Config**: `provider: "aws-secrets-manager"`.

## 3. Usage Pattern
In `src/config/config.ts`, replace direct `process.env` access with:

```typescript
const secret = await secretsProvider.getSecret("OPENAI_API_KEY");
```
