---
title: "RFC 02: PostgreSQL Storage Adapter"
status: "Draft"
---

# RFC 02: Relational Storage (PostgreSQL)

## Objective
Move persistent data (Sessions, History) from JSON files to a relational database to support ACID compliance, high concurrency, and advanced querying.

## 1. The `Storage` Interface

Refactor `config/sessions/store.ts` to generic interfaces.

```typescript
export interface SessionStoreAdapter {
  load(key: string): Promise<SessionEntry | null>;
  save(key: string, entry: SessionEntry): Promise<void>;
  list(filter: SessionFilter): Promise<SessionEntry[]>;
}
```

## 2. Database Schema

We will use `drizzle-orm` or `prisma` to manage these tables.

### Table: `sessions`
Stores the metadata for a conversation.
```sql
CREATE TABLE sessions (
  id VARCHAR(255) PRIMARY KEY, -- 'sessionKey'
  user_id VARCHAR(255),
  channel_id VARCHAR(50),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP,
  metadata JSONB -- Flexible bag for extra props
);
```

### Table: `audit_logs`
Immutable record of all actions (Enterprise only).
```sql
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  timestamp TIMESTAMP DEFAULT NOW(),
  actor_id VARCHAR(255), -- User email or ID
  action VARCHAR(100), -- 'restart_service', 'chat.send'
  resource VARCHAR(255), -- target entity
  details JSONB -- PII Redacted details
);
CREATE INDEX idx_audit_time ON audit_logs(timestamp);
```

## 3. Migration Strategy

1.  **Dual Write**: For the first release, write to both JSON and DB (if enabled).
2.  **Import Tool**: Create `scripts/import-sessions-to-db.ts` to iterate `~/.openclaw/sessions/*.json` and `INSERT` into Postgres.
3.  **Config**:
    ```yaml
    storage:
      backend: "postgres" # vs "file"
    ```
