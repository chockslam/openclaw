---
title: "RFC 04: Admin Gateway API"
status: "Draft"
---

# RFC 04: Admin Gateway API

## Objective
Expose a protected REST API ("Control Plane") that allows the Admin Dashboard (and scripts) to manage the OpenClaw cluster.

## 1. Scope & Auth
*   **Base URL**: `/v1/admin`
*   **Authorization**: Requires `ADMIN_SCOPE` (or an OIDC token with `role: admin`).

## 2. Endpoints

### User Management
*   `GET /v1/admin/users`: List all known users (paginated).
*   `GET /v1/admin/users/:id`: Get user details and roles.
*   `POST /v1/admin/users/:id/roles`: Assign roles (e.g. `{"roles": ["developer"]}`).
*   `DELETE /v1/admin/users/:id/session`: Kill active WebSocket session (force disconnect).

### Audit Logs
*   `GET /v1/admin/audit`: Search audit logs.
    *   Query Params: `start`, `end`, `user_id`, `action`.
    *   Response: JSON array of audit events (from Postgres).

### System Status (Cluster)
*   `GET /v1/admin/cluster/nodes`: List active Gateway nodes (from Redis).
*   `POST /v1/admin/cluster/drain`: Mark a node for draining (stop accepting new connections).

## 3. Implementation
These endpoints should be implemented in `src/gateway/server-methods/admin.ts`.
They must use the `StorageAdapter` (RFC 02) to query the database and the `ClusterStateAdapter` (RFC 01) to query Redis.
